

function NotFound(){
    return(
        <p className="Not-Found-Message"> Page you are looking for is not found.</p>
    )
}

export default NotFound;